package com.feb22;

import java.util.Scanner;

public class SumVSXor {
	static long solve(long n) {
        /*long count=0;
        for(int i=0;i<=n;i++) {
            if((n+i) == (n^i))
                count++;
        }
        return count;*/
        
        long c = 0;
        
        		while(n>0){
        		     c += n%2==0?0:1;
        		     n/=2; 
        		}
        		c=(long) Math.pow(2,c);
        		return c;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        long n = in.nextLong();
        long result = solve(n);
        System.out.println(result);
    }
}
