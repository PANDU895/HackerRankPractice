package com.feb16;

import java.util.HashMap;
import java.util.Map;

public class HashMapTest {

	public static void main(String[] args) {
		Map<String,Integer> map = new HashMap<String,Integer>();
		map.put("s", 1);
		map.put("r", 2);
		map.put("i", 3);
		Map<String,Integer> map1 = new HashMap<String,Integer>();
		/*map.put("s", 1);
		map.put("r", 2);
		map.put("i", 3);*/

		System.out.println(map.containsKey("r"));
		System.out.println(map.containsValue(3));
		System.out.println(map.keySet());
		System.out.println(map.entrySet());
		System.out.println(map1);
		map1.putAll(map);
		System.out.println(map1);
		map1.putIfAbsent("i", 8);
		System.out.println(map1);
		map1.putIfAbsent("k", 4);
		System.out.println(map1);
		map1.remove("k", 3);
		System.out.println(map1);
		/*map1.remove("k", 4);
		System.out.println(map1);*/
		map1.replace("k", 3,5);
		System.out.println(map1);
		map1.replace("k", 4,5);
		System.out.println(map1);
	}

}
