package com.feb16;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionsTest {
// addAll, binarySearch,sort, disjoint, fill, frequency, indexOfSubList, lastIndexOfSubList, max, min, nCopies, replaceAll
	//rotate, swap, 
	public static void main(String[] args) {
		List<String> list1 = new ArrayList<String>();
		List<String> list3 = new ArrayList<String>();
		List<String> list4= new ArrayList<String>();
		list4.add("srikanth2");
		list4.add("s1");
		list3.add("aaaa");
		list3.add("srikanth2");
		List list2 = new ArrayList();
		list2.add("srikanth");
		list2.add(2);
		list2.add(2.3);
		list2.add("sss");
		
		list1.add("srikanth");
		list1.add("srikanth1");
		list1.add("srikanth2");
		Collections.addAll(list1, "s1");
		System.out.println(list1);
		System.out.println(Collections.binarySearch(list1,"srikanth2"));
		System.out.println(Collections.binarySearch(list1,"s1"));// added item not searching
//		System.out.println(Collections.checkedCollection(list2, String.class));// not under stand*****
		System.out.println(Collections.disjoint(list1, list3));// will tell is there any common atleast one element
		System.out.println(list1);
		Collections.copy(list1, list3);// its not copy, its doing overriding the index's. parent size should be more than child.
		System.out.println(list1);
		System.out.println(Collections.disjoint(list1, list3));// will tell is there any common atleast one element
		Collections.fill(list3, "hhhh");// fill with given string in all indexs
		System.out.println(list3);
		System.out.println(Collections.frequency(list1, "srikanth2"));// it will give count of given string.
		list1.add("srikanth3");
		list1.add("s1");
		System.out.println(Collections.indexOfSubList(list1, list4));// will give starting index of child list in parent list
		System.out.println(Collections.lastIndexOfSubList(list1, list4));// will give last index of child list
		System.out.println(Collections.max(list1));// if string give max lenth, if int, give max value
		System.out.println(Collections.min(list1));
		System.out.println(Collections.nCopies(4, list4));// just use to get copys
		System.out.println(list1);
		Collections.replaceAll(list1, "s1", "s2");
		System.out.println(list1);
//		Collections.reverse(list1);
//		System.out.println(list1);
		Collections.rotate(list1, 4);
		System.out.println(list1);
		
//		Collections.shuffle(list1);
		Collections.sort(list1);
		System.out.println(list1);
		Collections.swap(list1, 0, 1);
		System.out.println(list1);
		
		// create map
	      Map<String, Boolean> map = new HashMap<String, Boolean>();

	      // create a set from map
	      Set<String> set = Collections.newSetFromMap(map); 

	      // add values in set
	      set.add("Java"); 
	      set.add("C");
	      set.add("C++");

	      // set and map values are
	      System.out.println("Set is: " + set);
	      System.out.println("Map is: " + map);
	}

}
