package com.feb16;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetTest {

	public static void main(String[] args) {
		TreeSet<String> set = new TreeSet<String>();
		set.add("s");
		set.add("r");
		set.add("i");
		set.add("k");
		
		TreeSet<Integer> set1 = new TreeSet<Integer>();
		set1.add(3);
		set1.add(1);
		set1.add(9);
		set1.add(6);
		
		System.out.println(set1);
		System.out.println("higher->"+set1.higher(6));
		System.out.println("lower->"+set1.lower(6));
		System.out.println("ceiling->"+set1.ceiling(4));
		System.out.println("floor->"+set1.floor(4));
		System.out.println(set1.first());
		System.out.println(set1.last());
		
		System.out.println(set1);
		System.out.println(set1.tailSet(5));
		System.out.println(set1.tailSet(2,false));
		set1.pollFirst();
		set1.pollLast();
		System.out.println(set1);

	}

}
