package com.feb16;

import java.math.BigInteger;
import java.util.Scanner;

public class SumSubString {
	static BigInteger substrings(String balls) {
        //long n = Long.valueOf(balls);
        BigInteger result=new BigInteger("0");
        for(int i=0;i<balls.length();i++){
            //result +=Integer.valueOf(balls.charAt(i));
            for(int j=i+1;j<balls.length()+1;j++){
                //System.out.println(i+" "+j);
                //System.out.println(balls.substring(i,j));
                result = result.add(new BigInteger(balls.substring(i,j)));
                //System.out.println(result);
            }
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String balls = in.next();
        BigInteger result = substrings(balls);
        System.out.println(result);
        in.close();
    }
}
