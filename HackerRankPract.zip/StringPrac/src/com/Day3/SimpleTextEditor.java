package com.Day3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SimpleTextEditor {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt(), t,d;
		String s;
		StringBuilder sb = new StringBuilder();
		List<String> map = new ArrayList<String>();
		for (int i = 0; i < n; i++) {
			t = sc.nextInt();
			switch (t) {
			case 1:
				storeUnde(sb,map);
				s = sc.next();
				sb.append(s);
				break;
			case 2:
				storeUnde(sb,map);
				d = sc.nextInt();
				if(sb.length()-d <=0)
					sb.replace(0, sb.length(), "");
				else
					sb.replace(sb.length()-d, sb.length(), "");
				break;
			case 3:
				d=sc.nextInt();
				if(sb.length()>=d)
					System.out.println(sb.charAt(d-1));
				break;
			case 4:
				sb = new StringBuilder(map.get(map.size()-1));
				map.remove(map.size()-1);
				break;

			default:
				break;
			}
		}
	}
	public static void storeUnde(StringBuilder sb,List<String> map) {
		map.add(sb.toString());
	}
}
