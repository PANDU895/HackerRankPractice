package com.Day3;

import java.util.Arrays;
import java.util.Scanner;

public class EqualStacks {

	/*public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
        int n1 = in.nextInt();
        int n2 = in.nextInt();
        int n3 = in.nextInt();
        int h1[] = new int[n1];
        for(int h1_i=0; h1_i < n1; h1_i++){
            h1[h1_i] = in.nextInt();
        }
        int h2[] = new int[n2];
        for(int h2_i=0; h2_i < n2; h2_i++){
            h2[h2_i] = in.nextInt();
        }
        int h3[] = new int[n3];
        for(int h3_i=0; h3_i < n3; h3_i++){
            h3[h3_i] = in.nextInt();
        }
        long []sums = new long[3];
        giveSums(h1,h2,h3,sums);
        if(isAllSame(sums)){
        	System.out.println(sums[0]);
        } else {
        	long min = Arrays.stream(sums).summaryStatistics().getMin();
    		while(true) {
	        	long temp;
	        	while(h1.length > 0) {
	        		h1 = Arrays.copyOfRange(h1, 1,h1.length);
	        		temp = giveSum(h1);
	        		if(temp <= min) {
	        			min = temp;break; 
	        		}
	        	}
	        	while(h2.length > 0) {
	        		h2 = Arrays.copyOfRange(h2, 1,h2.length);
	        		temp = giveSum(h2);
	        		if(temp <= min) {
	        			min = temp;break; 
	        		}
	        	}
	        	while(h3.length > 0) {
	        		h3 = Arrays.copyOfRange(h3,1, h3.length);
	        		temp = giveSum(h3);
	        		if(temp <= min) {
	        			min = temp;break; 
	        		}
	        	}
	        	giveSums(h1, h2, h3, sums);
	        	if(isAllSame(sums))
        			break;
    		}
        	System.out.println(sums[0]);
        }
	}
	
	private static void giveSums(int[] h1, int[] h2, int[] h3,long[] sums) {
		sums[0] = giveSum(h1);
        sums[1] = giveSum(h2);
        sums[2] = giveSum(h3);
	}
	private static long giveSum(int[] h1) {
		return Arrays.stream(h1).summaryStatistics().getSum();
	}
	private static boolean isAllSame(long[] sums) {
		return Arrays.stream(sums).distinct().count() == 1;
	}*/

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n1 = in.nextInt();
		int n2 = in.nextInt();
		int n3 = in.nextInt();
		int h1[] = new int[n1];
		for (int h1_i = (n1 - 1); h1_i >= 0; h1_i--) {
			h1[h1_i] = in.nextInt();
		}
		int h2[] = new int[n2];
		for (int h2_i = (n2 - 1); h2_i >= 0; h2_i--) {
			h2[h2_i] = in.nextInt();
		}
		int h3[] = new int[n3];
		for (int h3_i = (n3 - 1); h3_i >= 0; h3_i--) {
			h3[h3_i] = in.nextInt();
		}
		Arrays.parallelPrefix(h1, (a, b) -> (a + b));
		Arrays.parallelPrefix(h2, (a, b) -> (a + b));
		Arrays.parallelPrefix(h3, (a, b) -> (a + b));
		int i = h1.length - 1, j = h2.length - 1, k = h3.length - 1, height = 0;
		while (i >= 0 && j >= 0 && k >= 0) {
			if (h1[i] == h2[j] && h2[j] == h3[k]) {
				height = h1[i];
				break;
			} else if (h1[i] > h2[j]) {
				i--;
			} else if (h2[j] > h3[k]) {
				j--;
			} else {
				k--;
			}
		}
		System.out.println(height);
	}
}
