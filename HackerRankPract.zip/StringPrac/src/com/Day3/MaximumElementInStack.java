package com.Day3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class MaximumElementInStack {

	public static void main(String[] args) {
		/*Scanner sc = new Scanner(System.in);
		int n = sc.nextInt(), t;
		Stack<Integer> st = new Stack<Integer>();
		for (int i = 0; i < n; i++) {
			t = sc.nextInt();
			switch (t) {
			case 1:
				st.add(sc.nextInt());
				break;
			case 2:
				st.removeElement(st.lastElement());
				break;
			case 3:
				System.out.println(Collections.max(st));
				break;
			}
		}*/
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt(), t;
		List<Integer> st = new ArrayList<Integer>();
		for (int i = 0; i < n; i++) {
			t = sc.nextInt();
			switch (t) {
			case 1:
				st.add(sc.nextInt());
				break;
			case 2:
				st.remove(st.size()-1);
				break;
			case 3:
				System.out.println(Collections.max(st));
				break;
			}
		}
	}
}
