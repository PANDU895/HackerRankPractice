package com.feb20;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TwoCharacters {
	static int twoCharaters(String s) {
        if(isDisctictChar(s)) {
            return s.length();
        } else {
            List<String[]> disList = (List) Stream.of(s.toCharArray()).distinct().collect(Collectors.toList());
            System.out.println(disList.get(0));
            String sTemp=null;
            whileLoop:
            while(true) {
            	String [] strArray = disList.get(0);
            	for(String str:strArray) {
            		sTemp = new String(s);
            		sTemp = sTemp.replaceAll(str, "");
            		if(isDisctictChar(s)){
            			break whileLoop;
            		}
            	}
            	for(int i=0;i<disList.size();i++) {
            		for(int j=i+1;j<disList.size();j++) {
            			sTemp = new String(s);
            			sTemp = sTemp.replaceAll(strArray[i], "");
            			sTemp = sTemp.replaceAll(strArray[j], "");
                		if(isDisctictChar(sTemp)){
                			break whileLoop;
                		}
            		}
            	}
            }
            return s.length();
        }
    }
    static boolean isDisctictChar(String s1) {
        char first = s1.charAt(0);
        char second = s1.charAt(1);
        for(int i=2;i<s1.length();i++) {
            if(i%2==0 && first != s1.charAt(i)) {
                return false;
            } else if(i+1 <s1.length() && second != s1.charAt(i+1)){
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int l = in.nextInt();
        String s = in.next();
        int result = twoCharaters(s);
        System.out.println(result);
        in.close();
    }
}
