package com.feb20;

import java.util.Scanner;

public class SeparateTheNumbers {
	 static void separateNumbers(String s) {
		 boolean temp = false;
		 long a = 0 ;
	        for(int i=1;i<=s.length()/2;i++) {
	        	StringBuilder sb = new StringBuilder();
	            a = Long.valueOf(s.substring(0,i));
	            long b = a;
	            sb.append(a);
	            while(sb.length() <s.length()) {
	            	sb.append(++b);
	            }
	            if(s.equals(sb.toString())) {
	            	temp=true;break;
	            }
	        }
	        if(temp) {
	        System.out.println("YES "+a);
	        } else {
	        	System.out.println("NO");	
	        }
	        
	    }

	    public static void main(String[] args) {
	        Scanner in = new Scanner(System.in);
	        int q = in.nextInt();
	        for(int a0 = 0; a0 < q; a0++){
	            String s = in.next();
	            separateNumbers(s);
	        }
	        in.close();
	    }
}
