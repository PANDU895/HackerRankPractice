package com.feb20;

import java.util.Scanner;

public class HackerRankInString {
	static String hackerrankInString(String s) {
        String fine = "hackerrank";
        for(int i=0;i<fine.length();) {
            for(int j=0;j<s.length();) {
                if(fine.charAt(i) == s.charAt(j)) {
                    i++;
                    if(i==fine.length()){
                        return "YES";
                    }
                }
                j++;
            }
            if(i==fine.length()){
                return "YES";
            }
            break;
        }
        return "NO";
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int q = in.nextInt();
        for(int a0 = 0; a0 < q; a0++){
            String s = in.next();
            System.out.println(hackerrankInString(s));
        }
        in.close();
    }
}
