package com.feb20;

import java.util.Scanner;

public class CaesarCipher {
	static String caesarCipher(String s, int k) {
        if(k > 26){
			k = k%26;
		}
        StringBuilder sb = new StringBuilder();
        for(int i=0;i<s.length();i++){
            int temp = Integer.valueOf(s.charAt(i));
            if(97<=temp && 122>=temp) {
                if(temp+k >122){
                    temp = 97+((temp+k)-123);
                } else {
                    temp = temp +k;
                }
                sb.append((char)(temp));
            } else if(65<=temp && 90>=temp) {
                if(temp+k >90){
                    temp = 65+((temp+k)-91);
                } else {
                    temp = temp +k;
                }
                sb.append((char)(temp));
            } else {
                sb.append(s.charAt(i));
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        String s = in.next();
        int k = in.nextInt();
        String result = caesarCipher(s, k);
        System.out.println(result);
        in.close();
    }
}
