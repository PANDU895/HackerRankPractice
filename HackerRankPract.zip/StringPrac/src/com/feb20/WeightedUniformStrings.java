package com.feb20;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class WeightedUniformStrings {
	public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s = in.next();
        int n = in.nextInt();
        List<Integer> list = new ArrayList<Integer>();
        Set<Integer> list1 = new HashSet<Integer>();
        for(int a0 = 0; a0 < n; a0++){
            list.add(in.nextInt());
        }
        for(int i = 0; i < s.length();){
            if(i+1 == s.length()) {
                list1.add(getValue(s.charAt(i)));
                i++;
            } else if(s.charAt(i) == s.charAt(i+1)) {
                int temp =0;
                temp = getValue(s.charAt(i));
                list1.add(temp);
                while(true) {
                    temp += getValue(s.charAt(++i));
                    list1.add(temp);
                    if(i+1 == s.length() || s.charAt(i) != s.charAt(i+1)) {
                        break;
                    }
                }
            } else {
                list1.add(getValue(s.charAt(i)));i++;
            }
        }
        for(int i=0;i<list.size();i++) {
            if(list1.contains(list.get(i))) {
                System.out.println("Yes");
            } else{
                System.out.println("No");
            }
        }
    }
    public static int getValue(char a) {
        int i = Integer.valueOf(a);
        int temp = 96;
        return i-96;
    }
}
