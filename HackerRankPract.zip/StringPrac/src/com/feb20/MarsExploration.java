package com.feb20;

import java.util.Scanner;

public class MarsExploration {
	static int marsExploration(String s) {
        int count=0;
        for(int i=0;i<s.length();i=i+3) {
            if(s.charAt(i) != 'S'){
                count++;
            }
            if(s.charAt(i+1) != 'O'){
                count++;
            }
            if(s.charAt(i+2) != 'S'){
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s = in.next();
        int result = marsExploration(s);
        System.out.println(result);
        in.close();
    }
}
