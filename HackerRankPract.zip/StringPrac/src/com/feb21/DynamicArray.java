package com.feb21;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DynamicArray {
	public static void main(String[] args) {
        /*Scanner sc = new Scanner(System.in);
        int aSize = sc.nextInt();
        int q = sc.nextInt();
        int lastAns = 0;
        List<int[]> list = new ArrayList<int[]>();
        list.add(new int[aSize]);
        list.add(new int[aSize]);
        for(int i=0;i<q;i++) {
            int qType = sc.nextInt();
            int x = sc.nextInt();
            int y = sc.nextInt();
            int temp = (x^lastAns)%2;
            if(qType == 1) {
                list.get(temp)[list.get(temp).length] = y;
            } else {
                int temp1 = y%list.get(temp).length;
                lastAns = list.get(temp)[temp1];
                System.out.println(lastAns);
            }
        }*/
        Scanner sc = new Scanner(System.in);
        int aSize = sc.nextInt();
        int q = sc.nextInt();
        int lastAns = 0;
        List<List<Integer>> list = new ArrayList<List<Integer>>();
        list.add(new ArrayList<Integer>());
        list.add(new ArrayList<Integer>());
        for(int i=0;i<q;i++) {
            int qType = sc.nextInt();
            int x = sc.nextInt();
            int y = sc.nextInt();
            int temp = (x^lastAns)%2;
            if(qType == 1) {
                list.get(temp).add(y);
            } else {
                int temp1 = y%list.get(temp).size();
                lastAns = list.get(temp).get(temp1);
                System.out.println(lastAns);
            }
        }
    }
}
