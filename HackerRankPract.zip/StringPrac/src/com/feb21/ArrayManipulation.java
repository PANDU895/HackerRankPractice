package com.feb21;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayManipulation {
	public static void main(String[] args) {
		/*
		 * Scanner in = new Scanner(System.in); int n = in.nextInt(); int m =
		 * in.nextInt(); BigInteger []ar = new BigInteger[n]; for(int a0 = 0; a0
		 * < m; a0++){ int a = in.nextInt(); int b = in.nextInt(); int k =
		 * in.nextInt(); for(int i=a-1;i<b;i++) { if(null != ar[i]) ar[i] =
		 * ar[i].add(new BigInteger(String.valueOf(k))); else ar[i] = new
		 * BigInteger(String.valueOf(k)); } }
		 * System.out.println(Arrays.stream(ar).max(new Comparator<BigInteger>()
		 * {
		 * 
		 * @Override public int compare(BigInteger o1, BigInteger o2) { if(null
		 * != o1) return o1.compareTo(o2); else return -1; } }).get());
		 * in.close();
		 */
		/*
		 * Scanner in = new Scanner(System.in); int n = in.nextInt(); int m =
		 * in.nextInt(); List<Long> list = new ArrayList<Long>(); //int []ar =
		 * new int[n]; for(int a0 = 0; a0 < m; a0++){ int a = in.nextInt(); int
		 * b = in.nextInt(); int k = in.nextInt();
		 * 
		 * for(int i=a-1;i<b;i++) { for(int j=list.size();j<=i;j++) {
		 * list.add((long) 0); } if(i<list.size()) { list.set(i,list.get(i)+k);
		 * } else { list.set(i,(long) k); } //ar[i]+=k; }
		 * 
		 * //System.out.println(Arrays.stream(ar).max().getAsInt()); }
		 * System.out.println(Collections.max(list)); in.close();
		 */

		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int m = scan.nextInt();

		// This will be the "difference array". The entry arr[i]=k indicates
		// that arr[i] is exactly k units larger than arr[i-1]
		long[] arr = new long[n];

		int lower;
		int upper;
		long sum;

		for (int i = 0; i < n; i++)
			arr[i] = 0;
		for (int i = 0; i < m; i++) {
			lower = scan.nextInt();
			upper = scan.nextInt();
			sum = scan.nextInt();
			arr[lower - 1] += sum;
			if (upper < n)
				arr[upper] -= sum;
			System.out.println(Arrays.toString(arr));
		}

		long max = 0;
		long temp = 0;

		for (int i = 0; i < n; i++) {
			temp += arr[i];
			if (temp > max)
				max = temp;
		}
		System.out.println(max);
	}
}
