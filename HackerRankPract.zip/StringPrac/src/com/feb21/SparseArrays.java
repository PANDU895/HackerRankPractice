package com.feb21;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class SparseArrays {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        List<String> list = new ArrayList<String>();
        for(int i=0;i<n;i++) {
            list.add(sc.next());
        }
        int q = sc.nextInt();
        for(int i=0;i<q;i++) {
            System.out.println(Collections.frequency(list,sc.next()));
        }
    }
}
