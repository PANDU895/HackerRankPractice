package com.feb21;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class LeftShiftByNFromI {

	public static void main(String[] args) {
		int by =2;
		int []array = new int[]{23,51,100,1,67,49,24};
		int []array1 = new int[]{23,51,100,1,67,49,24};
		System.out.println(Arrays.toString(array));
		
//		int[] result = siftedArray(array,by,"r");
		List<Integer>  list = Arrays.stream(array).boxed().collect(Collectors.toList());
		Collections.rotate(list, 2);
		System.out.println(Arrays.toString(list.stream().mapToInt(i->i).toArray()));
		
		List<Integer> list1 = Arrays.stream(array1).boxed().collect(Collectors.toList());
		Collections.rotate(list1, list1.size()-2);
		System.out.println(Arrays.toString(list1.stream().mapToInt(i->i).toArray()));
		/*Collections.rotate(Arrays.asList(array1), array1.length-2);
		System.out.println(Arrays.toString(array1));*/
//		System.out.println(Arrays.toString(result));
	}
	public static int[] siftedArray(int[] array,int by,String d) {
		int[] result = new int[array.length];
		int temp  =0;
		if("l".equalsIgnoreCase(d)) {
			for(int j=by;j<array.length;j++) {
				result[temp]=array[j];temp++;
			}
			for(int j=0;j<by;j++) {
				result[temp]=array[j];temp++;
			}
		} else {
			for(int j=array.length-by;j<array.length;j++) {
				result[temp]=array[j];temp++;
			}
			for(int j=0;j<array.length-by;j++) {
				result[temp]=array[j];temp++;
			}
		}
		return result;
	}

}
