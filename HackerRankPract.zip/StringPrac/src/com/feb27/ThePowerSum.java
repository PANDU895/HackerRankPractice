package com.feb27;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ThePowerSum {
	static int powerSum(int X, int N) {
	        int exactOrNear=0,maxSubs=0,count=0,i,temp=0;
	        List<Integer> list = new ArrayList<Integer>();
	        for(i=1;i<X/N;i++) {
	            temp = (int) Math.pow(i,N);
	            list.add(i);
	            if(temp >= X) {
	            	exactOrNear =i;
	            }
	        }
	        temp =0;
	        for(i=1;i<X/N;i++) {
	            temp += Math.pow(i,N);
	            if(temp >= X) {
	                maxSubs = i;break;
	            }
	        }
	        
	        for(int j=1;j<=maxSubs;j++) {
	        	
	        }
	        
	        
	        
	        
	        
	        
	        
	        /*List<Integer> list;
	        for(i=2;i<=maxSubs;i++) {
	            list = new ArrayList<Integer>();
	            for(int j = 0;j<i;j++) {
	                for(int k=exactOrNear-1;k>0;k--) {
	                    list.add()
	                } 
	            }
	            int[] arr = new int[i];
	            arr[0] = startAt;
	            for(int j=startAt-1;j>0;j--) {
	                
	            }
	        }
	        for(i=exact-1;i>0;i--) {
	            
	        }*/
	        
	        /*int rang = x/N,count=0,temp;
	        for(int i=rang;i>0;i--) {
	            for(int j=i;j>0;j--) {
	                if()
	            }
	            temp=0;
	            for(int j=i;j>0;j--) {
	                temp += Math.pow(j,N);
	                if(temp == X){
	                    count++;break;
	                } else {
	                    
	                }
	            }
	        }*/
	        return count;
	    }

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int X = in.nextInt();
		int N = in.nextInt();
		int result = powerSum(X, N);
		System.out.println(result);
		in.close();
	}
}
