package com.feb27;

import java.util.Arrays;
import java.util.Scanner;

public class MatrixLayerRotation {
	static void matrixRotation(int[][] matrix) {
		int rows = matrix.length, cols = matrix[0].length, outerValLeft = 0, outerValTemp;
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (i == 0) {
					if (j == 0) {
						outerValLeft = matrix[i][j];
						matrix[i][j] = matrix[i][j + 1];
					} else {
						if (j == cols - 1) {
							matrix[i][j] = matrix[i + 1][j];
						} else {
							matrix[i][j] = matrix[i][j + 1];
						}
					}
				} else if (i == rows - 1) {
					outerValTemp = matrix[i][j];
					matrix[i][j] = outerValLeft;
					outerValLeft = outerValTemp;
				} else {
					if (j == 0) {
						outerValTemp = matrix[i][j];
						matrix[i][j] = outerValLeft;
						outerValLeft = outerValTemp;
					} else if (j == cols - 1) {
						if (i == rows - 1) {
							matrix[i][j] = outerValLeft;
						} else {
							matrix[i][j] = matrix[i + 1][j];
						}
					} else {
						if(i==1 && j==1 && rows-2 >1 && cols-2 >1) {
							int [][]sub = new int[rows-2][cols-2];
							for (int k = 1; k < rows-1; k++) {
								for (int l =1; l < cols-1; l++) {
									sub[k-1][l-1]= matrix[k][l];
								}
							}
							System.out.println("____________");
							System.out.println(Arrays.deepToString(sub));
							matrixRotation(sub);
							for (int k = 1; k < rows-1; k++) {
								for (int l =1; l < cols-1; l++) {
									matrix[k][l] = sub[k-1][l-1];
								}
							}
						}
					}
				}

			}
		}
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int m = in.nextInt();
		int n = in.nextInt();
		int r = in.nextInt();
		int[][] matrix = new int[m][n];
		for (int matrix_i = 0; matrix_i < m; matrix_i++) {
			for (int matrix_j = 0; matrix_j < n; matrix_j++) {
				matrix[matrix_i][matrix_j] = in.nextInt();
			}
		}
		for(int i=0;i<r;i++) {
			matrixRotation(matrix);
		}
		for (int k = 0; k < matrix.length; k++) {
			for (int l =0; l < matrix[0].length; l++) {
				System.out.print(matrix[k][l]+" ");
			}
			System.out.println();
		}
		in.close();
	}
}
