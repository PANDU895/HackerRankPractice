package com.feb27;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class HowManySubstrings {
	public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int q = in.nextInt();
        String s = in.next();
        Set<String> set = new HashSet<String>();
        for(int a0 = 0; a0 < q; a0++){
            int left = in.nextInt();
            int right = in.nextInt();
            set = new HashSet<String>();
            for(int i=0;i<=right-left+1;i++) {
                for(int j=left;j<=right-i;j++) {
                    //System.out.println(j+"-"+(j+i)+"-"+s.substring(j,j+i+1));
                    set.add(s.substring(j,j+i+1));
                }
            }
            //System.out.println(set);
            System.out.println(set.size());
        }
    }
}
