package com.feb27;

public class IntegerTest {

	public static void main(String[] args) {
		int a = 010;
		System.out.println(a);

	}

}
