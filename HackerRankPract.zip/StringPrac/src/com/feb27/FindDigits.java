package com.feb27;

import java.util.Scanner;

public class FindDigits {
	static int findDigits(int n) {
		int count = 0, temp;
		String s = String.valueOf(n);
		for (int i = 0; i < s.length(); i++) {
			temp = Integer.parseInt(String.valueOf(s.charAt(i)));
			if (temp != 0 && n % temp == 0)
				count++;
		}
		return count;
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int t = in.nextInt();
		for (int a0 = 0; a0 < t; a0++) {
			int n = in.nextInt();
			int result = findDigits(n);
			System.out.println(result);
		}
		in.close();
	}
}
