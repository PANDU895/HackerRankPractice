package com.sri;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Spliterator;
import java.util.function.BinaryOperator;
import java.util.stream.Collectors;

public class ArraysTest {

	public static void main(String[] args) {
		
		String[] str = new String[3];
		str[0] = "a";
		str[1] = "b";
		str[2] = "c";
		List<String> list = Arrays.asList(str);
		System.out.println(list);
		
		System.out.println(Arrays.binarySearch(str, "c"));
		String[] newStr = Arrays.copyOf(str, 2);
		System.out.println(newStr[1]);
		
		String[] newStr1 = Arrays.copyOfRange(str, 0,3);
		System.out.println(newStr1.length + " " +newStr1[2]);
		System.out.println(Arrays.equals(str, newStr1));
		System.out.println(Arrays.deepEquals(str, newStr1));
		
		 String[][] twoDArray = new String[][] {
					{"ONE", "TWO", "THREE", "FOUR"},
					{"FIVE", "SIX", "SEVEN"},
					{"EIGHT", "NINE", "TEN", "ELEVEN", "TWELVE"}
				};
		 String[][] twoDArray1 = new String[][] {
					{"ONE", "TWO", "THREE", "FOUR"},
					{"FIVE", "SIX", "SEVEN"},
					{"EIGHT", "NINE", "TEN", "ELEVEN", "TWELVE"}
				};
		 
		 System.out.println(Arrays.equals(twoDArray, twoDArray1));
			System.out.println("-->"+Arrays.deepEquals(twoDArray, twoDArray1));
		
		System.out.println(Arrays.deepToString(twoDArray));
		Arrays.fill(str, "sri");
		System.out.println(Arrays.deepToString(str));
		int []integ = new int[]{1,2,3,4,2,1,8};
		Arrays.fill(integ,0,4,3);
		System.out.println(Arrays.toString(integ));
		Arrays.parallelSort(integ,0,4);
		System.out.println(Arrays.toString(integ));
		Arrays.parallelSort(integ);
		System.out.println(Arrays.toString(integ));
		String[] pass = new String[]{"the","cake","is","a","lie","thec","ak","ei","sal","ie"};
		//String[] newPass = new String[pass.length]{pass};
		Arrays.sort(pass,new Comparator<String>(){
	           public int compare(String s1,String s2) {
	               if(s1.length() > s2.length()) {
	                   return -1;
	               } else if(s1.length() < s2.length()) {
	                   return 1;
	               } else {
	                   return 0;
	               }
	           } 
	        });
		System.out.println(Arrays.deepToString(pass));
		Spliterator<Integer> sp = Arrays.spliterator(integ);
		Spliterator<Integer> sp1 = sp.trySplit();
		Spliterator<Integer> sp2 = sp1.trySplit();
		sp.forEachRemaining(System.out::println);
		System.out.println("-----------");
		sp1.forEachRemaining(System.out::println);
		System.out.println("-----------");
		sp2.forEachRemaining(System.out::println);
		
	}

}
