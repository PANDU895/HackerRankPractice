package com.sri;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MyComparator {

	public static void main(String[] args) {
		MyComparator myComp = new MyComparator();
		List<EmpBean> nameList = myComp.getEmpBeanList();
		Collections.sort(nameList, new Comparator<EmpBean>() {
			@Override
			public int compare(EmpBean arg0, EmpBean arg1) {
				if(arg0.getCompanyName().compareTo(arg1.getCompanyName()) == 0) {
					if(arg0.getId()>arg1.getId()){
						return 1;
					} else if(arg0.getId()<arg1.getId()) {
						return -1;
					} else
						return 0;
				} else
					return arg0.getCompanyName().compareTo(arg1.getCompanyName());
			}
		});
		nameList.forEach(emp -> System.out.println(emp.toString()));
		Collections.sort(nameList, new Comparator<EmpBean>() {

			@Override
			public int compare(EmpBean arg0, EmpBean arg1) {
				if(arg0.getId()>arg1.getId()){
					return 1;
				} else if(arg0.getId()<arg1.getId()) {
					return -1;
				} else
					return 0;
			}
		});
		nameList.forEach(emp -> System.out.println(emp.toString()));

	}
	
	public List<EmpBean> getEmpBeanList() {
		List<EmpBean> empBean = new ArrayList<EmpBean>();
		empBean.add(new EmpBean("Srikanth",96127,"capgemini"));
		empBean.add(new EmpBean("Aswin",96131,"Capgemini"));
		empBean.add(new EmpBean("Omprekash",96126,"capgemini"));
		empBean.add(new EmpBean("lokesh",96135,"Openstrides"));
		return empBean;
	}

}
