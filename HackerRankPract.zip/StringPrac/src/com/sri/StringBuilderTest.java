package com.sri;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class StringBuilderTest {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("sdfasd a sd dsdsd sfsdfsdfssdfdd ");
		System.out.println(sb);
		System.out.println(sb.capacity());
		System.out.println(sb.length());
//		System.out.println(sb.deleteCharAt(2));
		System.out.println(sb.insert(1, true));
		System.out.println(sb.replace(0, 5, "***"));
		System.out.println(sb.reverse());
		Map<String,Integer> map = new HashMap<String,Integer>();
		Set<Entry<String,Integer>> mapSet = map.entrySet();
        for(Entry<String,Integer> entry :  mapSet) {
            if(entry.g)
        }
	}

}
