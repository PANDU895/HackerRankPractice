package com.sri;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class MissingNumbers {

    static int[] missingNumbers(int[] arr, int[] brr) {
        
    	Set<Integer> list = new TreeSet<Integer>();
        boolean test=true;
        int j=0,i=0;
        for(;i<arr.length;) {
        	if(j>=brr.length){
        		break;
        	}
            for (;j<brr.length;){
                System.out.println("arr[i] : "+arr[i]);
                System.out.println("brr[j] : "+brr[j]);
                if(arr[i] == brr[j]) {
                    i++;j++;break;
                } else {
                    if(!list.contains(brr[j])){
                        list.add(brr[j]);
                    }
                    j++;break;
                }
            }
        }
         System.out.println("---------- ");
         int[] missings = new int[list.size()];
         Iterator it = list.iterator();
         int k=0;
         while(it.hasNext()) {
            missings[k] = (int) it.next();
            k++;
        }
        return missings;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] arr = new int[n];
        for(int arr_i = 0; arr_i < n; arr_i++){
            arr[arr_i] = in.nextInt();
        }
        int m = in.nextInt();
        int[] brr = new int[m];
        for(int brr_i = 0; brr_i < m; brr_i++){
            brr[brr_i] = in.nextInt();
        }
        int[] result = missingNumbers(arr, brr);
        for (int i = 0; i < result.length; i++) {
            System.out.print(result[i] + (i != result.length - 1 ? " " : ""));
        }
        System.out.println("");


        in.close();
    }
}
