package com.sri;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class SimilarStrings {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
        int size = in.nextInt();
        int q = in.nextInt();
        String str = in.next();
        List<List<Integer>> qs = new ArrayList<List<Integer>>();
        for(int i=0;i<q;i++) {
            List<Integer> temp = new ArrayList<Integer>();
            temp.add(in.nextInt());
            temp.add(in.nextInt());
            qs.add(temp);
        }
        for(List<Integer> list : qs) {
            if(list.get(0) == 1 && list.get(1) == 1) {
                System.out.println(size);
            } else {
                countOfSubSame(list, str);
            }
        }
	}

	private static void countOfSubSame(List<Integer> list, String str) {
    	String sub = str.substring(list.get(0)-1,list.get(1));
        Map<String,List<Integer>> sameIndex = new LinkedHashMap<String,List<Integer>>();
        List<Integer> notSameIndex = new ArrayList<Integer>();
        List<Integer> temp;
    	for(int j=0;j<sub.length();j++) {
    		if(!sameIndex.keySet().contains(String.valueOf(sub.charAt(j)))) {
	    		temp = new ArrayList<Integer>();
	        	for(int k=j+1;k<sub.length();k++) {
	        		if(sub.charAt(j) == sub.charAt(k)){
	        			if(!temp.contains(j))
	        				temp.add(j);
	        			if(!temp.contains(k))
	        				temp.add(k); 
	        		}
	        	}
	        	if(!temp.isEmpty())
	        		sameIndex.put(String.valueOf(sub.charAt(j)), temp);
    		}
        }
    	Set<String> keys = sameIndex.keySet();
    	for(int i=0;i<sub.length();i++) {
    		if(!keys.contains(String.valueOf(sub.charAt(i)))){
    			notSameIndex.add(i);
    		}
    	}
    	int dif = (list.get(1)-list.get(0))+1;
    	int count=0;
    	for(int i=0,j=dif;j<=str.length();i++,j++) {
    		if(isSamePateron(str.substring(i, j),sameIndex,notSameIndex)) {
    			count++;
    		}
    	}
    	System.out.println(count);
	}

	private static boolean isSamePateron(String substring, Map<String,List<Integer>> sameIndex,List<Integer> notSameIndex) {
		boolean result = true;
		if(sameIndex.size()>0) {
			Iterator<String> it = sameIndex.keySet().iterator();
			outerloop:
			while(it.hasNext()) {
				String stemp = it.next();
				List<Integer> itr =sameIndex.get(stemp);
				if(!itr.isEmpty()) {
					int first = itr.get(0);
					for(int i=1;i<itr.size();i++) {
						if(substring.charAt(first)!=substring.charAt(itr.get(i))){
							result = false;break outerloop;
						}
					}
				}
			}
		}
		if(result) {
			outer:
			for(int x=0;x<notSameIndex.size();x++) {
				char st = substring.charAt(notSameIndex.get(x));
				for(int z=notSameIndex.get(x)+1;z<notSameIndex.size();z++) {
					if(st==substring.charAt(z)){
						result = false;break outer;
					}
				}
				if(substring.indexOf(st) != substring.lastIndexOf(st)) {
					result = false;break;
				}
			}
		}
		if(result){
			System.out.println();
		}
		return result;
	}
}
