package com.sri;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class BinaryRepresentation {

	public static void main(String[] args) {
		/*int i = 4;
		int j = i>>2;
		String binaryString = Integer.toBinaryString(i);
		System.out.println(binaryString);
		System.out.println(Integer.parseInt(binaryString,2));
		System.out.println(j);
		*/
		
		int a=-2,b= 0,count=0;
		for(int i=a;i<=b;i++) {
			String s = Integer.toBinaryString(i);
			for(int j=0;j<s.length();j++) {
				int x = Integer.parseInt(String.valueOf(s.charAt(j)));
				List<String> myList = new ArrayList<String>(Arrays.asList(s.split("")));
				System.out.println(Collections.frequency(myList, "1"));
//				System.out.println(myList);
				count+=x;
			}
		}
		System.out.println(count);
				
		
		
	}

}
