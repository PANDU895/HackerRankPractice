package com.sri;

public class MathJava {

	public static void main(String[] args) {
		System.out.println(Math.abs(1.3));

	}

}
