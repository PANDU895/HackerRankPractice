package com.sri;

import java.util.Scanner;

public class ArrayTransfose {

	public static void main(String[] args) {
		int [][]m1 = new int[3][3];
		int [][] m2 = new int[3][3];
		Scanner sc = new Scanner(System.in);
		System.out.println("enter matrix one with "+m1.length+" size:");
		int i,j;
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				m1[i][j] = sc.nextInt();
			}
		}
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				m2[j][i] = m1[i][j];
			}
		}
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				System.out.print(m2[i][j]+" ");
			}
			System.out.println();
		}
	}

}
