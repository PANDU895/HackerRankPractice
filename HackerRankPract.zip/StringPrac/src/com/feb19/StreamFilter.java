package com.feb19;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamFilter {

	public static void main(String[] args) {
/*		List<Employee> list = new ArrayList<>();
		list.add(new Employee("Sachin", 45000));
		list.add(new Employee("Nilesh", 55000));
		list.add(new Employee("Sanjay", 65000));

		List filteredList = list.stream().filter(emp -> emp.getSalary() > 50000).collect(Collectors.toList());
		System.out.println(filteredList);

		List revisedSalList = list.stream().map(emp -> emp.getSalary() * 2).collect(Collectors.toList());
		System.out.println(revisedSalList);*/
		int i=9, j=7;
		System.out.println(Math.abs(j - i));
		List<Integer> l = new ArrayList<Integer>();
		l.add(2);
		l.add(5);
		l.add(1);
		l.add(9);
		//Stream.of(l.toArray()).filter(e -> ()).peek(e -> System.out.println(e));
		
		l.stream().filter(e -> (e > 1)).peek(n -> System.out.println(n)).collect(Collectors.toList());
		
		l.stream().filter(e -> (e > 1)).forEach(System.out::print);
		System.out.println(l.stream().filter(e -> (e > 1)));
		

	}
}

class Employee {
	private String name;
	private int salary;

	public Employee(String name, int salary) {
		super();
		this.name = name;
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", salary=" + salary + "]";
	}

}
