package com.feb19;

import java.util.StringJoiner;

public class SwapWithoutVariableOrAdd {

	public static void main(String[] args) {
		int a =4,b=2;
		a =a^b;
		b=a^b;
		a=a^b;
		System.out.println(a+" "+b);
		StringJoiner sj = new StringJoiner("srikanth");
		System.out.println(sj);
		sj.add("1");
		sj.add("2");
		//sj.add("3");
		System.out.println(sj);
		sj.merge(new StringJoiner("2"));
		System.out.println(sj);
	}

}
