package com.Day3;

import java.util.Arrays;
import java.util.stream.IntStream;

public class IntStreamTest {

	public static void main(String[] args) {
		System.out.println(IntStream.of(new int[]{10,20}).count());
		System.out.println(IntStream.of(new int[]{10,20}).sum());
		System.out.println(IntStream.of(new int[]{10,20}).average());
		System.out.println(Arrays.toString(IntStream.of(new int[]{10,20,10}).distinct().toArray()));
		System.out.println(IntStream.of(new int[]{10,20}).findAny());
		System.out.println(IntStream.of(new int[]{10,20}).findFirst());
		System.out.println(Arrays.toString(IntStream.of(new int[]{10,20,3,5,6,7}).limit(3).toArray()));
		System.out.println(Arrays.toString(IntStream.of(new int[]{10,20,4,5,7,1}).skip(4).toArray()));
		System.out.println(IntStream.of(new int[]{10,20}).max());
		System.out.println(IntStream.of(new int[]{10,20}).min());
		System.out.println(Arrays.toString(IntStream.of(new int[]{10,20,4,6,7}).sorted().toArray()));
		System.out.println(Arrays.toString(IntStream.of(new int[]{10,20,4,5,6,1,3}).unordered().toArray()));
		

	}

}
