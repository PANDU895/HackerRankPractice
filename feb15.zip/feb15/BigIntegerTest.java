package com.Day3;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class BigIntegerTest {

	public static void main(String[] args) {
//		BigInteger bigInt = new BigInteger(String.valueOf(4));
	/*	System.out.println(Integer.toBinaryString(8));
		System.out.println(Integer.toBinaryString(9));*/
//		System.out.println(bigInt.add(new BigInteger(String.valueOf(2))));
//		System.out.println(bigInt.flipBit(0));
		int n=6;
		BigInteger j;
		int temp;
		BigInteger bigInt = new BigInteger(String.valueOf(6)); //0110
		/*System.out.println(bigInt.toString(2));
		System.out.println(new BigInteger("8").toString(2));*/
		/*System.out.println(bigInt.toString(2));
		String s = Integer.toBinaryString(n);
		for(int i=0;i<s.length();i++) {
			j = bigInt.flipBit(i);
			System.out.println(j+"-"+j.toString(2));
		}*/
		System.out.println(bigInt.add(new BigInteger("4")));
		System.out.println(bigInt.pow(3));//6*6*6
		System.out.println(bigInt.and(new BigInteger("3"))); // 3=0011, output 2 = 010
		System.out.println(bigInt.or(new BigInteger("3"))); // 3=011, ouput 7 = 111
		System.out.println(bigInt.xor(new BigInteger("3")));//3=011, ouput 5 = 101
		System.out.println("*"+bigInt.andNot(new BigInteger("3"))); // ~3=100, ouput 4 = 100
		System.out.println(bigInt.bitCount());//
		System.out.println(bigInt.bitLength());// length of string
		System.out.println(bigInt.shiftLeft(1));//
		System.out.println(bigInt.shiftRight(1));//
		System.out.println(bigInt.divide(new BigInteger("2")));//
		System.out.println(Arrays.deepToString(bigInt.divideAndRemainder(new BigInteger("4"))));//
		System.out.println(bigInt.nextProbablePrime());//3=011, ouput 5 = 101
	}

}
