package com.feb26;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class MissingNumbers {
	static int[] missingNumbers(int[] arr, int[] brr) {
        Map<Integer,Integer> a = new HashMap<Integer,Integer>();
        Map<Integer,Integer> b = new HashMap<Integer,Integer>();
        for(int i : arr) {
            if(a.containsKey(i)){
                a.put(i,a.get(i)+1);
            } else {
                a.put(i,1);
            }
        }
        for(int i : brr) {
            if(b.containsKey(i)){
                b.put(i,b.get(i)+1);
            } else {
                b.put(i,1);
            }
        }
        Set<Integer> rSet = new TreeSet<Integer>();
        Iterator<Integer> keys = b.keySet().iterator();
        while(keys.hasNext()) {
            Integer key = keys.next();
            if(!a.containsKey(key)) {
                rSet.add(key);
            } else if(a.get(key) < b.get(key)) {
                rSet.add(key);
            }
        }
        int [] result = new int[rSet.size()];
        Iterator<Integer> sKeys = rSet.iterator();
        int i=0;
        while(sKeys.hasNext()) {
            result[i] = sKeys.next();i++;
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] arr = new int[n];
        for(int arr_i = 0; arr_i < n; arr_i++){
            arr[arr_i] = in.nextInt();
        }
        int m = in.nextInt();
        int[] brr = new int[m];
        for(int brr_i = 0; brr_i < m; brr_i++){
            brr[brr_i] = in.nextInt();
        }
        int[] result = missingNumbers(arr, brr);
        for (int i = 0; i < result.length; i++) {
            System.out.print(result[i] + (i != result.length - 1 ? " " : ""));
        }
        System.out.println("");


        in.close();
    }
}
