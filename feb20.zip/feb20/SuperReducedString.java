package com.feb20;

import java.util.Scanner;

public class SuperReducedString {

	static String super_reduced_string(String s){
		StringBuilder sb = new StringBuilder(s);
        while(sb.length() > 0) {
        	boolean modi = true;
            for(int i=0;i<sb.length()-1;i++) {
                String temp = String.valueOf(sb.charAt(i));
                System.out.println(temp+" "+sb.charAt(i+1));
                System.out.println(temp.equals(String.valueOf(sb.charAt(i+1))));
                if(temp.equals(String.valueOf(sb.charAt(i+1)))){
//                	sb.replace(0, sb.length(), sb.substring(0, i)+sb.substring(i+2,sb.length()));
                	sb.replace(i, i+2, "");
                	System.out.println(sb);
                	modi = false;
                }
            }
            if(modi){
            	break;
            }
        }
        if(sb.length()>0){
        	return sb.toString();
        }
        return "Empty String";
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s = in.next();
        String result = super_reduced_string(s);
        System.out.println(result);
    }
}
