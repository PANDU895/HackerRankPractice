package com.feb20;

import java.util.Scanner;

public class Pangrams {
	 public static void main(String args[] ) throws Exception {
	        Scanner sc = new Scanner(System.in);
	        String str = sc.nextLine();
	        boolean test = true;
	        for(char ch = 'a' ; ch <= 'z' ; ch++ ) {
	            if(!str.contains(String.valueOf(ch)) && !str.contains(String.valueOf(ch).toUpperCase())){
	                test = false;
	                break;
	            }
	        }
	        if(test) {
	            System.out.println("pangram");
	        } else {
	            System.out.println("not pangram");
	        }
	    }
}
