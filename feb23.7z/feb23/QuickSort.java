package com.feb23;

public class QuickSort {

	public static void main(String[] args) {
		

	}

}
