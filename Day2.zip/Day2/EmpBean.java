package com.sri;

public class EmpBean {
	private String name;
	private int id;
	private String companyName;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public EmpBean(String name, int id, String companyName) {
		super();
		this.name = name;
		this.id = id;
		this.companyName = companyName;
	}
	@Override
	public String toString() {
		return "EmpBean [name=" + name + ", id=" + id + ", companyName="
				+ companyName + "]";
	}
	
}
