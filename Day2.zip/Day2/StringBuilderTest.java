package com.sri;

public class StringBuilderTest {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("sdfasd a sd dsdsd sfsdfsdfssdfdd ");
		System.out.println(sb);
		System.out.println(sb.capacity());
		System.out.println(sb.length());
//		System.out.println(sb.deleteCharAt(2));
		System.out.println(sb.insert(1, true));
		System.out.println(sb.replace(0, 5, "***"));
		System.out.println(sb.reverse());
	}

}
