package com.sri;

import java.util.Scanner;

public class RotateString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
//		str.replaceAll("a", "*");
//		System.out.println(str.replaceAll("a", "*"));
//		System.out.println(str.replace("a", "*"));
		int n=3;
		/*while(n>0) {
		str = str.charAt(str.length()-1) + str.substring(0, str.length()-1);
		System.out.println(str);
		n--;
		}*/
		str = str.substring(str.length()-n,str.length()) + str.substring(0, str.length()-n);
		System.out.println(str);
	}

}
