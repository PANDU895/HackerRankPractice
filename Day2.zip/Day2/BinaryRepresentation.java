package com.sri;

public class BinaryRepresentation {

	public static void main(String[] args) {
		int i = 4;
		int j = i>>2;
		String binaryString = Integer.toBinaryString(i);
		System.out.println(binaryString);
		System.out.println(Integer.parseInt(binaryString,2));
		System.out.println(j);

	}

}
