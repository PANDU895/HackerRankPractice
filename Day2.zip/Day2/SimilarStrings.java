package com.sri;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class SimilarStrings {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
        int size = in.nextInt();
        int q = in.nextInt();
        String str = in.next();
        List<List<Integer>> qs = new ArrayList<List<Integer>>();
        for(int i=0;i<q;i++) {
            List<Integer> temp = new ArrayList<Integer>();
            temp.add(in.nextInt());
            temp.add(in.nextInt());
            qs.add(temp);
        }
        for(List<Integer> list : qs) {
            if(list.get(0) == 1 && list.get(1) == 1) {
                System.out.println(size);
            } else {
                countOfSubSame(list, str);
            }
        }
	}

	private static void countOfSubSame(List<Integer> list, String str) {
    	String sub = str.substring(list.get(0)-1,list.get(1));
         List<Integer> sameIndex = new ArrayList<Integer>();
        List<Integer> notSameIndex = new ArrayList<Integer>();
    	for(int j=0;j<sub.length();j++) {
        	for(int k=j+1;k<sub.length();k++) {
        		if(sub.charAt(j) == sub.charAt(k)){
        			if(!sameIndex.contains(j))
        				sameIndex.add(j);
        			if(!sameIndex.contains(k))
        				sameIndex.add(k); 
        		} else {
        			if(!notSameIndex.contains(j))
        				notSameIndex.add(j);
        			if(!notSameIndex.contains(k))
        				notSameIndex.add(k);
        		}
        	}
        }
    	Iterator it = notSameIndex.iterator();
    	while(it.hasNext()) {
    		int next = (int) it.next();
    		if(sameIndex.contains(next)) {
    			it.remove();
    		}
    	}
    	int dif = (list.get(1)-list.get(0))+1;
    	int count=0;
    	for(int i=0,j=dif;j<=str.length();i++,j++) {
    		if(isSamePateron(str.substring(i, j),sameIndex,notSameIndex)) {
    			count++;
    		}
    	}
    	System.out.println(count);
	}

	private static boolean isSamePateron(String substring, List<Integer> sameIndex,List<Integer> notSameIndex) {
		boolean result = true;
		if(sameIndex.size()>0) {
			int first = sameIndex.get(0);
			for(int z=1;z<sameIndex.size();z++) {
				if(substring.charAt(first)!=substring.charAt(sameIndex.get(z)))
					result = false;
			}
		}
		if(result) {
			outerloop:
			for(int z=0;z<notSameIndex.size();z++) {
				for(int x=z+1;x<notSameIndex.size();x++) {
					if(substring.charAt(z)==substring.charAt(x))
						result = false;break outerloop;
				}
			}
		}
		return result;
	}

}
