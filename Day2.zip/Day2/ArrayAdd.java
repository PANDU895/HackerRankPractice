package com.sri;

import java.util.Scanner;

public class ArrayAdd {

	public static void main(String[] args) {
		int [][]m1 = new int[3][3];
		int [][] m2 = new int[3][3];
		int [][] m3 = new int[3][3];
		Scanner sc = new Scanner(System.in);
		System.out.println("enter matrix one with "+m1.length+" size:");
		int i,j;
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				m1[i][j] = sc.nextInt();
			}
		}
		System.out.println("enter matrix two with "+m1.length+" size:");
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				m2[i][j] = sc.nextInt();
			}
		}
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				m3[i][j] = m1[i][j]+m2[i][j];
			}
		}
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				System.out.print(m3[i][j]+" ");
			}
			System.out.println();
		}
	}

}
