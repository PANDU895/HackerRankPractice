package com.sri;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ForJDK8 {

	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("asdf");
		list.add("ss");
		
		list.forEach(li->System.out.println(li));
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("a", 1);
		map.put("b", 2);
		
		map.forEach((a,b)->System.out.println("key:"+a +",value:"+b));
		
		switch ("sri") {
		case "bsd":
			System.out.println("a");
			break;
		case "sri":
			System.out.println("b");
			break;

		default:
			break;
		}
	}

}
