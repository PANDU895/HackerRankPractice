package com.feb16;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

public class ArrayListTest {

	public static void main(String[] args) {
		List<String> list1 = new ArrayList<String>();
		list1.add("srikanth");
		list1.add("srikanth1");
		list1.add("srikanth2");
		List<String> list2 = new ArrayList<String>();
		list2.add("srikanth");
		System.out.println(list1);
		list1.addAll(list2);
		System.out.println(list1);
		System.out.println(list1.contains("srikanth2"));
//		list1.forEach(s->System.out.println(s));
		Predicate<String> pr = p->p=="srikanth2";
		list1.removeIf(pr);
		System.out.println(list1);
		list1.set(1, "asr1");
		System.out.println(list1);
		list1.sort(new Comparator<String>() {
			@Override
			public int compare(String arg0, String arg1) {
				return arg0.compareTo(arg1);
			}
		});
		System.out.println(list1);
		System.out.println(list1.subList(0, 1));
		
		ArrayList<Integer> arrlist = new ArrayList<Integer>(5);
		arrlist.add(1);
		System.out.println(arrlist);
		System.out.println(arrlist.size());
		/*System.out.println(list1.size());
		list1.clear();
		System.out.println(list1.size());*/
		
		String orig[] = { "1st", "2nd", "3rd", "4th", "5th", "1st", "2nd", "3rd",
		        "4th", "5th" };
		    String act[] = { "2nd", "3rd", "6th" };
		    List origList = new ArrayList(Arrays.asList(orig));
		    List actList = Arrays.asList(act);

		    System.out.println(origList.retainAll(actList));
		    System.out.println(origList);
		

	}

}
