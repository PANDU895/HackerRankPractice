package com.feb16;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Abbreviation {
	static String abbreviation(String a, String b) {
        String t = a.toUpperCase();
        if(t.contains(b)) {
            //System.out.println(t.indexOf(b));
            //System.out.println(t.indexOf(b)+b.length());
            String temp = a.substring(0,t.indexOf(b))+a.substring(t.indexOf(b)+b.length(),a.length());
            //System.out.println(temp);
            boolean tem = false;
            List<String> tempList = new ArrayList<String>();
            for(int i=0;i<temp.length();i++) {
                if(Character.isUpperCase(temp.charAt(i))){
                	tem = true;tempList.add(String.valueOf(temp.charAt(i)));
                }
            }
            String temp1 = new String();
            if(tem) {
            	for(String s : tempList) {
            		temp1 = a.replace(s.toLowerCase(), "");
            	}
            	if(temp1.toUpperCase().contains(b))
            		return "YES";
            	return "NO";
            }
            return "YES";
        } else {
        	StringBuilder sb = new StringBuilder();
        	for(int i=0;i<a.length();i++) {
                if(Character.isUpperCase(a.charAt(i))){
                    sb.append(a.charAt(i));
                }
            }
        	if(sb.toString().contains(b))
        		return "YES";
            return "NO";
        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int q = in.nextInt();
        for(int a0 = 0; a0 < q; a0++){
            String a = in.next();
            String b = in.next();
            String result = abbreviation(a, b);
            System.out.println(result);
        }
        in.close();
    }
}
