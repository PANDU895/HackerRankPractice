package com.feb21;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ArrayManipulation {
	 public static void main(String[] args) {
		 /*Scanner in = new Scanner(System.in);
	        int n = in.nextInt();
	        int m = in.nextInt();
	        BigInteger []ar = new BigInteger[n];
	        for(int a0 = 0; a0 < m; a0++){
	            int a = in.nextInt();
	            int b = in.nextInt();
	            int k = in.nextInt();
	            for(int i=a-1;i<b;i++) {
	            	if(null != ar[i])
	            		ar[i] = ar[i].add(new BigInteger(String.valueOf(k)));
	            	else
	            		ar[i] = new BigInteger(String.valueOf(k));
	            }
	        }
	         System.out.println(Arrays.stream(ar).max(new Comparator<BigInteger>() {
				@Override
				public int compare(BigInteger o1, BigInteger o2) {
					if(null != o1)
						return o1.compareTo(o2);
					else
						return -1;
				}
			}).get());
	        in.close();*/
		 Scanner in = new Scanner(System.in);
	        int n = in.nextInt();
	        int m = in.nextInt();
	        List<Long> list = new ArrayList<Long>();
	        //int []ar = new int[n];
	        for(int a0 = 0; a0 < m; a0++){
	            int a = in.nextInt();
	            int b = in.nextInt();
	            int k = in.nextInt();
	            
	            for(int i=a-1;i<b;i++) {
	                for(int j=list.size();j<=i;j++) {
	                    list.add((long) 0);
	                }
	                if(i<list.size()) {
	                    list.set(i,list.get(i)+k);
	                } else {
	                    list.set(i,(long) k);
	                }
	                //ar[i]+=k;
	            }
	            
	            //System.out.println(Arrays.stream(ar).max().getAsInt());
	        }
	        System.out.println(Collections.max(list));
	        in.close();
	    }
}
