package com.feb22;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ClosestNumbers {
	static int[] closestNumbers(int[] arr) {
        int smallDif = Integer.MAX_VALUE;
        List<Integer> list = new ArrayList<Integer>();
        for(int i=0;i<arr.length;i++) {
            for(int j=i+1;j<arr.length;j++) {
                int temp = Math.abs(arr[i] - arr[j]);
                if(temp < smallDif) {
                    smallDif = temp;
                }
            }
        }
        for(int i=0;i<arr.length;i++) {
            for(int j=i+1;j<arr.length;j++) {
                int temp = Math.abs(arr[i] - arr[j]);
                if(temp == smallDif) {
                    list.add(arr[i]);
                    list.add(arr[j]);
                }
            }
        }
        Collections.sort(list);
        return list.stream().mapToInt(i->i).toArray();
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] arr = new int[n];
        for(int arr_i = 0; arr_i < n; arr_i++){
            arr[arr_i] = in.nextInt();
        }
        int[] result = closestNumbers(arr);
        for (int i = 0; i < result.length; i++) {
            System.out.print(result[i] + (i != result.length - 1 ? " " : ""));
        }
        System.out.println("");


        in.close();
    }
}
