package com.feb22;

import java.util.Arrays;
import java.util.Scanner;

public class IntroToTutorialChallenges {
	static int introTutorial(int V, int[] arr) {
        return Arrays.binarySearch(arr, V);
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int V = in.nextInt();
        int n = in.nextInt();
        int[] arr = new int[n];
        for(int arr_i = 0; arr_i < n; arr_i++){
            arr[arr_i] = in.nextInt();
        }
        int result = introTutorial(V, arr);
        System.out.println(result);
        in.close();
    }
}
